
package com.example.wsra.controller;

import com.example.wsra.entity.Appointment;
import com.example.wsra.service.AppointmentService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;

    public AppointmentController(
            AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @PostMapping
    public ResponseEntity<?> book(
            @RequestBody Map<String, String> request) {

        try {
            String patientName = request.get("patientName");
            String patientEmail = request.get("patientEmail");
            String doctorIdValue = request.get("doctorId");
            String dateValue = request.get("date");
            String timeValue = request.get("time");

            if (patientName == null || patientName.isBlank()
                    || patientEmail == null || patientEmail.isBlank()
                    || doctorIdValue == null || dateValue == null
                    || timeValue == null) {
                throw new IllegalArgumentException(
                        "Please fill in all required fields.");
            }

            if (!patientEmail.matches(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                throw new IllegalArgumentException(
                        "Please enter a valid email address.");
            }

            Appointment appointment = appointmentService.book(
                    patientName.trim(),
                    patientEmail.trim(),
                    Long.parseLong(doctorIdValue),
                    LocalDate.parse(dateValue),
                    LocalTime.parse(timeValue)
            );

            Map<String, Object> response = new HashMap<>();
            response.put("id", appointment.getId());
            response.put("confirmationId",
                    appointment.getConfirmationId());
            response.put("patientName",
                    appointment.getPatientName());
            response.put("patientEmail",
                    appointment.getPatientEmail());
            response.put("doctorName",
                    appointment.getDoctorName());
            response.put("date",
                    appointment.getAppointmentDate());
            response.put("time",
                    appointment.getAppointmentTime());
            response.put("status", appointment.getStatus());
            response.put("message",
                    "Appointment booked successfully. "
                    + "Email sending was attempted.");

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", e.getMessage()));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                        "message",
                        "Unable to book appointment. Check server logs."
                    ));
        }
    }

    @GetMapping("/patient")
    public ResponseEntity<?> getPatientAppointments(
            @RequestParam String email) {

        if (email == null || email.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", "Email is required."));
        }

        return ResponseEntity.ok(
                appointmentService.getByEmail(email.trim()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancel(
            @PathVariable Long id,
            @RequestParam String email) {

        try {
            Appointment appointment =
                    appointmentService.cancel(id, email.trim());

            return ResponseEntity.ok(Map.of(
                    "message", "Appointment cancelled successfully.",
                    "status", appointment.getStatus()
            ));

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", e.getMessage()));
        }
    }
}
