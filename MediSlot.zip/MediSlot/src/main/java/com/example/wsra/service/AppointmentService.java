
package com.example.wsra.service;

import com.example.wsra.entity.Appointment;
import com.example.wsra.entity.Doctor;
import com.example.wsra.repository.AppointmentRepository;
import com.example.wsra.repository.DoctorRepository;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String senderEmail;

    public AppointmentService(
            AppointmentRepository appointmentRepository,
            DoctorRepository doctorRepository,
            JavaMailSender mailSender) {
        this.appointmentRepository = appointmentRepository;
        this.doctorRepository = doctorRepository;
        this.mailSender = mailSender;
    }

    @Transactional
    public Appointment book(
            String patientName,
            String patientEmail,
            Long doctorId,
            LocalDate appointmentDate,
            LocalTime appointmentTime) {

        if (patientName == null || patientName.isBlank()
                || patientEmail == null || patientEmail.isBlank()) {
            throw new IllegalArgumentException(
                    "Patient name and email are required.");
        }

        if (appointmentDate == null || appointmentTime == null) {
            throw new IllegalArgumentException(
                    "Appointment date and time are required.");
        }

        if (appointmentDate.isBefore(LocalDate.now())
                || (appointmentDate.equals(LocalDate.now())
                && appointmentTime.isBefore(LocalTime.now()))) {
            throw new IllegalArgumentException(
                    "Please select a future appointment date and time.");
        }

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Doctor not found."));

        if (!isWithinDoctorHours(doctor, appointmentTime)) {
            throw new IllegalArgumentException(
                    "Selected time is outside the doctor's working hours.");
        }

        boolean slotTaken =
                appointmentRepository
                    .existsByDoctorIdAndAppointmentDateAndAppointmentTimeAndStatus(
                            doctorId,
                            appointmentDate,
                            appointmentTime,
                            "BOOKED");

        if (slotTaken) {
            throw new IllegalArgumentException(
                    "This appointment slot is already booked.");
        }

        Appointment appointment = new Appointment();
        appointment.setConfirmationId(
                UUID.randomUUID().toString()
                    .replace("-", "").substring(0, 12).toUpperCase());
        appointment.setPatientName(patientName);
        appointment.setPatientEmail(patientEmail);
        appointment.setDoctorId(doctor.getId());
        appointment.setDoctorName(doctor.getName());
        appointment.setAppointmentDate(appointmentDate);
        appointment.setAppointmentTime(appointmentTime);
        appointment.setStatus("BOOKED");

        Appointment saved = appointmentRepository.save(appointment);

        // Send emails after saving the appointment.
        // Email failures are logged and do not undo the booking.
        sendPatientConfirmation(saved, doctor);
        sendDoctorNotification(saved, doctor);

        return saved;
    }

    private boolean isWithinDoctorHours(
            Doctor doctor, LocalTime selectedTime) {

        try {
            DateTimeFormatter formatter =
                    DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);

            LocalTime start =
                    LocalTime.parse(doctor.getArrivalTime(), formatter);
            LocalTime end =
                    LocalTime.parse(doctor.getDepartureTime(), formatter);

            return !selectedTime.isBefore(start)
                    && !selectedTime.isAfter(end);

        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException(
                    "Doctor's working hours have an invalid format.");
        }
    }

    private void sendPatientConfirmation(
            Appointment appointment, Doctor doctor) {

        String subject = "MediSlot Appointment Confirmation - "
                + appointment.getConfirmationId();

        String body =
                "Hello " + appointment.getPatientName() + ",\n\n"
                + "Your appointment has been booked successfully.\n\n"
                + "Confirmation ID: " + appointment.getConfirmationId() + "\n"
                + "Doctor: " + doctor.getName() + "\n"
                + "Specialization: " + doctor.getSpecialization() + "\n"
                + "Date: " + appointment.getAppointmentDate() + "\n"
                + "Time: " + appointment.getAppointmentTime() + "\n"
                + "Status: " + appointment.getStatus() + "\n\n"
                + "Thank you for using MediSlot.";

        sendEmail(appointment.getPatientEmail(), subject, body);
    }

    private void sendDoctorNotification(
            Appointment appointment, Doctor doctor) {

        String doctorEmail = doctor.getEmail();

        if (doctorEmail == null || doctorEmail.isBlank()) {
            System.err.println(
                    "Doctor email is missing for " + doctor.getName());
            return;
        }

        String subject = "New MediSlot Appointment - "
                + appointment.getConfirmationId();

        String body =
                "Hello " + doctor.getName() + ",\n\n"
                + "A new appointment has been booked.\n\n"
                + "Confirmation ID: " + appointment.getConfirmationId() + "\n"
                + "Patient: " + appointment.getPatientName() + "\n"
                + "Patient email: " + appointment.getPatientEmail() + "\n"
                + "Date: " + appointment.getAppointmentDate() + "\n"
                + "Time: " + appointment.getAppointmentTime() + "\n"
                + "Status: " + appointment.getStatus() + "\n\n"
                + "Please review this appointment in MediSlot.";

        sendEmail(doctorEmail, subject, body);
    }

    private void sendEmail(
            String recipient, String subject, String body) {

        if (senderEmail == null || senderEmail.isBlank()) {
            System.err.println(
                    "Email not sent: spring.mail.username is not configured.");
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(senderEmail);
            message.setTo(recipient);
            message.setSubject(subject);
            message.setText(body);

            mailSender.send(message);

            System.out.println("Email accepted for sending to: " + recipient);

        } catch (MailException ex) {
            System.err.println(
                    "Email could not be sent to " + recipient
                    + ": " + ex.getMessage());
        }
    }

    public List<Appointment> getByEmail(String email) {
        return appointmentRepository
                .findByPatientEmailOrderByAppointmentDateAsc(email);
    }

    @Transactional
    public Appointment cancel(Long appointmentId, String email) {
        Appointment appointment = appointmentRepository
                .findById(appointmentId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Appointment not found."));

        if (email == null
                || !appointment.getPatientEmail().equalsIgnoreCase(email)) {
            throw new IllegalArgumentException(
                    "You cannot cancel this appointment.");
        }

        appointment.setStatus("CANCELLED");
        return appointmentRepository.save(appointment);
    }
}
