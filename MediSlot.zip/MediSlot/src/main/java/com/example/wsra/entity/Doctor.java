
package com.example.wsra.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "doctors")
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String specialization;

    @Column(name = "arrival_time")
    private String arrivalTime;

    @Column(name = "departure_time")
    private String departureTime;

    @Column(name = "appointment_hours")
    private String appointmentHours;

    @Column(name = "email")
    private String email;

    public Doctor() {
    }

    public Doctor(String name, String specialization,
                  String arrivalTime, String departureTime,
                  String appointmentHours, String email) {
        this.name = name;
        this.specialization = specialization;
        this.arrivalTime = arrivalTime;
        this.departureTime = departureTime;
        this.appointmentHours = appointmentHours;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getAppointmentHours() {
        return appointmentHours;
    }

    public void setAppointmentHours(String appointmentHours) {
        this.appointmentHours = appointmentHours;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
