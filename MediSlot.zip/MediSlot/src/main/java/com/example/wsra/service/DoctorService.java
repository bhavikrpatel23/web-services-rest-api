
package com.example.wsra.service;

import com.example.wsra.entity.Doctor;
import com.example.wsra.repository.DoctorRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService implements CommandLineRunner {

    private final DoctorRepository doctorRepository;

    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    @Override
    public void run(String... args) {
        if (doctorRepository.count() == 0) {
            doctorRepository.saveAll(List.of(
                new Doctor(
                    "Dr Rahul Patel",
                    "Cardiologist",
                    "09:00 AM",
                    "05:00 PM",
                    "09:30 AM - 04:30 PM",
                    "bhavikrpatel2137z@gmail.com"
                ),
                new Doctor(
                    "Dr Priya Shah",
                    "Dermatologist",
                    "10:00 AM",
                    "06:00 PM",
                    "10:30 AM - 05:30 PM",
                    "bhavikrpatel2137z@gmail.com"
                ),
                new Doctor(
                    "Dr Amit Desai",
                    "General Physician",
                    "08:00 AM",
                    "02:00 PM",
                    "08:30 AM - 01:30 PM",
                    "bhavikrpatel2137z@gmail.com"
                )
            ));
        }
    }
}
