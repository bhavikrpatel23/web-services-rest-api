
const doctorCards = document.getElementById("doctorCards");
const doctorSelect = document.getElementById("doctorId");
const doctorSearch = document.getElementById("doctorSearch");
const selectedDoctorInfo = document.getElementById("selectedDoctorInfo");
const bookingForm = document.getElementById("bookingForm");
const reply = document.getElementById("reply");
const countdown = document.getElementById("countdown");
const bookButton = document.getElementById("bookButton");
const appointmentsContainer = document.getElementById("appointments");

const dateInput = document.getElementById("date");
const timeInput = document.getElementById("time");

let doctors = [];
let countdownInterval = null;

const doctorEmojis = ["👨🏻‍⚕️", "👩🏻‍⚕️", "👨🏽‍⚕️", "👩🏼‍⚕️"];

function localDateString(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

dateInput.min = localDateString();

function showReply(message, type = "success") {
    reply.textContent = message;
    reply.className = `notice ${type}`;
    reply.hidden = false;
}

function formatTime(value) {
    if (!value) return "Not specified";

    const match = value.match(/^(\d{2}):(\d{2})/);
    if (!match) return value;

    const hour = Number(match[1]);
    const minute = Number(match[2]);
    const date = new Date();
    date.setHours(hour, minute, 0, 0);

    return date.toLocaleTimeString([], {
        hour: "numeric",
        minute: "2-digit"
    });
}

function getDoctorHours(doctor) {
    return `Arrival: ${doctor.arrivalTime} · Departure: ${doctor.departureTime}`;
}

function renderDoctors(list) {
    doctorCards.replaceChildren();

    if (!list.length) {
        const empty = document.createElement("p");
        empty.className = "loading-text";
        empty.textContent = "No matching doctors found.";
        doctorCards.appendChild(empty);
        return;
    }

    list.forEach(doctor => {
        const card = document.createElement("article");
        card.className = "doctor-card";

        const top = document.createElement("div");
        top.className = "doctor-card-top";

        const avatar = document.createElement("div");
        avatar.className = "doctor-avatar";
        avatar.textContent = doctorEmojis[(Number(doctor.id) - 1) % doctorEmojis.length]
            || "🩺";

        const badge = document.createElement("span");
        badge.className = "availability-badge";
        badge.textContent = "● Listed";

        top.append(avatar, badge);

        const name = document.createElement("h3");
        name.textContent = doctor.name;

        const specialty = document.createElement("p");
        specialty.className = "doctor-specialty";
        specialty.textContent = doctor.specialization;

        const hours = document.createElement("div");
        hours.className = "doctor-hours";
        hours.textContent =
            `${getDoctorHours(doctor)}\nAppointment hours: ${doctor.appointmentHours}`;

        const button = document.createElement("button");
        button.className = "book-doctor";
        button.type = "button";
        button.textContent = "Book with this doctor →";

        button.addEventListener("click", () => {
            doctorSelect.value = String(doctor.id);
            updateSelectedDoctor();
            document.getElementById("booking").scrollIntoView({
                behavior: "smooth"
            });
        });

        card.append(top, name, specialty, hours, button);
        doctorCards.appendChild(card);
    });
}

async function loadDoctors() {
    try {
        const response = await fetch("/api/doctors");

        if (!response.ok) {
            throw new Error("Could not load doctors. Please refresh the page.");
        }

        doctors = await response.json();
        doctorSelect.replaceChildren();

        const placeholder = document.createElement("option");
        placeholder.value = "";
        placeholder.textContent = "Choose your doctor";
        doctorSelect.appendChild(placeholder);

        doctors.forEach(doctor => {
            const option = document.createElement("option");
            option.value = doctor.id;
            option.textContent = `${doctor.name} — ${doctor.specialization}`;
            doctorSelect.appendChild(option);
        });

        renderDoctors(doctors);
        updateSelectedDoctor();
    } catch (error) {
        doctorCards.textContent = error.message;
        showReply(error.message, "error");
    }
}

function updateSelectedDoctor() {
    const doctor = doctors.find(
        item => String(item.id) === doctorSelect.value
    );

    if (!doctor) {
        selectedDoctorInfo.textContent =
            "Select a doctor to view their schedule.";
        return;
    }

    selectedDoctorInfo.textContent =
        `${doctor.name} · ${doctor.specialization} · ` +
        `${getDoctorHours(doctor)} · Appointment hours: ${doctor.appointmentHours}`;
}

doctorSelect.addEventListener("change", updateSelectedDoctor);

doctorSearch.addEventListener("input", () => {
    const query = doctorSearch.value.trim().toLowerCase();

    renderDoctors(doctors.filter(doctor =>
        `${doctor.name} ${doctor.specialization} ${doctor.appointmentHours}`
            .toLowerCase().includes(query)
    ));
});

bookingForm.addEventListener("submit", async event => {
    event.preventDefault();

    if (countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
    }

    bookButton.disabled = true;
    countdown.hidden = true;
    showReply("Submitting your appointment...");

    const payload = {
        patientName: document.getElementById("patientName").value.trim(),
        patientEmail: document.getElementById("patientEmail").value.trim(),
        doctorId: doctorSelect.value,
        date: dateInput.value,
        time: timeInput.value
    };

    try {
        const response = await fetch("/api/appointments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || "Booking failed.");
        }

        showReply(
            `Appointment booked successfully! Confirmation ID: ` +
            `${result.confirmationId}. Doctor: ${result.doctorName}. ` +
            `Email sending was attempted; check your inbox.`
        );

        countdown.hidden = false;
        let remaining = 30;
        countdown.textContent = `Booking update in ${remaining} seconds`;

        countdownInterval = setInterval(() => {
            remaining -= 1;

            if (remaining <= 0) {
                clearInterval(countdownInterval);
                countdownInterval = null;
                countdown.textContent =
                    "30-second countdown complete. Your appointment is saved.";
                return;
            }

            countdown.textContent = `Booking update in ${remaining} seconds`;
        }, 1000);

        bookingForm.reset();
        dateInput.min = localDateString();
        updateSelectedDoctor();

    } catch (error) {
        showReply(error.message, "error");
    } finally {
        bookButton.disabled = false;
    }
});

document.getElementById("historyForm").addEventListener(
    "submit", async event => {
        event.preventDefault();

        const email = document.getElementById("historyEmail").value.trim();
        appointmentsContainer.textContent = "Loading your appointments...";

        try {
            const response = await fetch(
                `/api/appointments/patient?email=${encodeURIComponent(email)}`
            );

            const appointments = await response.json();

            if (!response.ok) {
                throw new Error(
                    appointments.message || "Could not load appointments."
                );
            }

            appointmentsContainer.replaceChildren();

            if (!appointments.length) {
                appointmentsContainer.textContent =
                    "No appointments found for this email address.";
                return;
            }

            appointments.forEach(appointment => {
                const card = document.createElement("article");
                card.className = "appointment-card";

                const details = document.createElement("p");
                details.textContent =
                    `Confirmation: ${appointment.confirmationId} · ` +
                    `Doctor: ${appointment.doctorName} · ` +
                    `Date: ${appointment.appointmentDate} · ` +
                    `Time: ${formatTime(appointment.appointmentTime)} · ` +
                    `Status: ${appointment.status}`;

                card.appendChild(details);

                if (appointment.status === "BOOKED") {
                    const cancelButton = document.createElement("button");
                    cancelButton.type = "button";
                    cancelButton.textContent = "Cancel appointment";

                    cancelButton.addEventListener("click", async () => {
                        cancelButton.disabled = true;

                        try {
                            const cancelResponse = await fetch(
                                `/api/appointments/${appointment.id}` +
                                `?email=${encodeURIComponent(email)}`,
                                { method: "DELETE" }
                            );

                            const result = await cancelResponse.json();

                            if (!cancelResponse.ok) {
                                throw new Error(
                                    result.message || "Cancellation failed."
                                );
                            }

                            showReply(result.message);
                            document.getElementById("historyForm")
                                .requestSubmit();

                        } catch (error) {
                            showReply(error.message, "error");
                            cancelButton.disabled = false;
                        }
                    });

                    card.appendChild(cancelButton);
                }

                appointmentsContainer.appendChild(card);
            });

        } catch (error) {
            appointmentsContainer.textContent = error.message;
        }
    }
);

loadDoctors();
