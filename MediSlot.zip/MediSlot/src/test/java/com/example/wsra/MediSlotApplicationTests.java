package com.example.wsra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediSlotApplicationTests {

	@Test
	void contextLoads() {
	}

}
